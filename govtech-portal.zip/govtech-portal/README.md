# GovTech – Smart Government Services Portal

A front-end academic project built with **HTML5, CSS3 and vanilla JavaScript** (no frameworks, no build step, no internet needed).

> ⚠️ **Demo only.** All data is sample data stored in the browser's `localStorage`. The site is **not** connected to any real government database or official service.

## Project structure

```
govtech-portal/
├── index.html   → Landing page, Register, Login, Citizen dashboard (single-page views)
├── admin.html   → Admin dashboard (separate page)
├── style.css    → All styling (navy/white theme, responsive, RTL-aware)
├── script.js    → All logic (shared by both pages)
└── README.md
```

## How to run in Visual Studio Code

1. Create a folder named `govtech-portal` and open it in VS Code (**File → Open Folder**).
2. Create four files with exactly these names and paste the matching code: `index.html`, `admin.html`, `style.css`, `script.js`.
3. Run it (either way works):
   - **Recommended:** install the **Live Server** extension (Ritwick Dey) → right-click `index.html` → **Open with Live Server**.
   - **Or** just double-click `index.html` to open it in Chrome / Edge.
4. Use Chrome or Edge for the best experience. (With Live Server, `localStorage` is shared between `index.html` and `admin.html` in every browser; some browsers isolate `file://` pages from each other.)

## Demo accounts

| Role    | Username  | Password      |
|---------|-----------|---------------|
| Citizen | `citizen` | `Citizen@123` |
| Admin   | `admin`   | `Admin@123`   |

Other seeded citizens (`sara_q`, `omar_k`, `mona_a`, `yousef_h`, `laila_m`) use `Citizen@123`; `khaled_j` is a *suspended* account (login is blocked). The login page has click-to-fill buttons for both main accounts. Logging in as `admin` redirects to `admin.html`.

## Features

| Requirement | Where |
|---|---|
| Landing: logo, navbar, Home, About, Services, Contact, footer, Login/Register buttons, EN/AR switch | `index.html` |
| Registration with full JS validation (live + on submit, duplicate username/email check, password strength meter) | `#view-register`, `script.js §10–11` |
| Login: validation, show/hide password, remember me, forgot password (demo reset), register link | `#view-login` |
| Citizen dashboard: welcome, profile (view/edit/change password), services, requests, status, notifications, logout | `#view-dashboard` |
| 8 services, each with description, request form, submit button and request tracking | `SERVICES` in `script.js §8` |
| Request tracking: timeline (Submitted → Under review → Decision), status history, track by ID | `requestDetailsHtml()` |
| Admin: users / requests / pending / approved / rejected counts, charts, users management (view, suspend, delete), requests management, search + filters, update status (with note) | `admin.html`, `Admin` in `script.js §12` |
| Arabic / English with full RTL layout | `I18N` in `script.js §3` |
| Responsive (desktop, tablet, mobile hamburger menu), animations, reduced-motion support | `style.css §12` |

## Notes for your report / viewers

- **Data storage:** `localStorage` keys `govtech_users`, `govtech_requests`, `govtech_notifications`, `govtech_messages`. Admin → **Reset demo data** restores the original sample data. To wipe everything, clear the site data in your browser.
- **Security:** passwords are hashed with a simple demo hash and sessions live in the browser. This is *not* real security; a production system needs a server, real password hashing (bcrypt/argon2), HTTPS and proper authorization.
- **Request status flow:** `Pending → Under Review → Approved / Rejected`. Each admin update adds a history entry and sends the citizen a notification.
- **Extending:** to add a service, add one object to the `SERVICES` array (fields, labels in EN/AR) plus its `sN_name` / `sN_desc` translation keys.
